<?php
header('Content-Type: application/json');

$host = "sql113.infinityfree.com";
$user = "if0_40500817";
$password = "n2lenMdvTOL7jeR";
$dbname = "if0_40500817_asasasasa"; // Ehliyet veritabanı adı

// Veritabanı bağlantısını oluşturun
$conn = mysqli_connect($host, $user, $password, $dbname);

if (!$conn) {
    die(json_encode(['error' => 'Veritabanı bağlantısı başarısız: ' . mysqli_connect_error()], JSON_UNESCAPED_UNICODE));
}

mysqli_set_charset($conn, "utf8");

// GET isteği ile gelen TC verisini güvenli bir şekilde alın
$tc = isset($_GET['tc']) ? mysqli_real_escape_string($conn, $_GET['tc']) : '';

// Kullanıcıdan eksik veri gelip gelmediğini kontrol edin
if (empty($tc)) {
    echo json_encode(['error' => 'TC değeri belirtilmedi'], JSON_UNESCAPED_UNICODE);
    exit;
}

// SQL sorgusu için prepared statement kullanın
$sql = "SELECT TC, vesika
        FROM 3kyokvesika WHERE TC = ?";
$stmt = mysqli_prepare($conn, $sql);

if ($stmt === false) {
    echo json_encode(['error' => 'Sorgu hazırlanırken hata oluştu: ' . mysqli_error($conn)], JSON_UNESCAPED_UNICODE);
    exit;
}

// Parametreyi bağla ve sorguyu çalıştır
mysqli_stmt_bind_param($stmt, "s", $tc);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$response = [];
if (mysqli_num_rows($result) > 0) {
    $output = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $output[] = $row;
    }
    $response['data'] = $output;
} else {
    $response['error'] = 'Kayıt bulunamadı';
}

echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// Veritabanı bağlantısını kapat
mysqli_close($conn);
?>
