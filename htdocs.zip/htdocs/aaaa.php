<?php
header('Content-Type: application/json');

$host = "sql113.infinityfree.com";
$user = "if0_40500817";
$password = "n2lenMdvTOL7jeR";
$dbname = "if0_40500817_asasasassa";

// Veritabanı bağlantısını oluşturun
$conn = mysqli_connect($host, $user, $password, $dbname);

if (!$conn) {
    die("Veritabanı bağlantısı başarısız: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8");

// GET isteği ile gelen verileri güvenli bir şekilde alın
$tc = isset($_GET['e']) ? mysqli_real_escape_string($conn, $_GET['e']) : '';

// Kullanıcıdan eksik veri gelip gelmediğini kontrol edin
if (empty($tc)) {
    $error = array('error' => 'TC değeri belirtilmedi');
    echo json_encode($error, JSON_UNESCAPED_UNICODE);
    exit;
}

// SQL sorgusu için prepared statement kullanın
$sql = "SELECT * FROM sowixsgk WHERE Sigortalı Adı = ? ";
$stmt = mysqli_prepare($conn, $sql);

if ($stmt === false) {
    die("Sorgu hazırlanırken hata oluştu: " . mysqli_error($conn));
}

// Bind the variables to the placeholders
mysqli_stmt_bind_param($stmt, "s", $tc);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

// Sorgu sonuçlarını JSON olarak döndürün
if (mysqli_num_rows($result) > 0) {
    $output = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $output[] = $row;
    }
    echo json_encode($output, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    $error = array('error' => 'Kayıt bulunamadı');
    echo json_encode($error, JSON_UNESCAPED_UNICODE);
}

// Veritabanı bağlantısını kapatın
mysqli_close($conn);
?>
