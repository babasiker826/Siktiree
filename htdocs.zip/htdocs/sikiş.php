<?php
// api/adsoyad.php - WAKANDADETANİRLAR Edition
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$ad    = trim($_GET['ad'] ?? '');
$soyad = trim($_GET['soyad'] ?? '');
$il    = trim($_GET['il'] ?? '');
$ilce  = trim($_GET['ilce'] ?? '');

if (empty($ad) || empty($soyad)) {
    echo json_encode([
        "hata" => "Ad ve soyad giriniz!"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Demirkoc API'si
$api_url = "https://demirkoc.alwaysdata.net/Api/adsoyad.php?ad=" . urlencode($ad) 
         . "&soyad=" . urlencode($soyad) 
         . "&il=" . urlencode($il) 
         . "&ilce=" . urlencode($ilce);

$response = @file_get_contents($api_url);

if ($response === false) {
    echo json_encode([
        "data" => [],
        "developer" => "WAKANDADETANİRLAR",
        "info" => "WakandaHepiniziSiker",
        "hata" => "Api Meşgul."
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$original = json_decode($response, true);

// Sadece data varsa al, yoksa boş array
$data = $original['data'] ?? [];

// TAM İSTEDİĞİN FORMAT
echo json_encode([
    "data"      => $data,
    "developer" => "@kandilar",
    "info"      => "WakandaHepiniziSiker"
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>