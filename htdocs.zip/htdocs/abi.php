<?php

header("Content-Type: application/json; charset=utf-8");

if (!isset($_GET["plaka"])) {
    die(json_encode(array("status" => "missing_parameter", "message" => "plaka parameter is required.")));
}

$plaka = $_GET["plaka"];

if (empty($plaka)) {
    die(json_encode(array("status" => "empty")));
}

if (strlen($plaka) < 3) {
    die(json_encode(array("status" => "PLAKA GİR")));
}

$baglan = new mysqli('sql113.infinityfree.com', 'if0_40500817', 'n2lenMdvTOL7jeR', 'if0_40500817_ss');

if ($baglan->connect_error) {
    die(json_encode(array("status" => "database_error", "message" => $baglan->connect_error)));
}

$sql = $baglan->prepare("SELECT * FROM `75k_plaka` WHERE `Plaka_No` = ?");
$sql->bind_param("s", $plaka);
$sql->execute();
$result = $sql->get_result();

$data = [
    "success" => "false",
    'Plaka_No' => null,
    'Isim' => null,
    'Tarih' => null,
    'GSMN' => null,
];

if ($row = $result->fetch_assoc()) {
    $data["success"] = "true";
    $data['Plaka_No'] = $row['Plaka_No'];
    $data['Isim'] = $row['Isim'];
    $data['Tarih'] = $row['Tarih'];
    $data['GSMN'] = $row['GSMN'];
}

echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>
