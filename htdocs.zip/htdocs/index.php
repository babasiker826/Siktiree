<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Just a Moment...</title>

    <!-- Cloudflare Turnstile (Gerçek CAPTCHA burada yükleniyor) -->
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>

    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background: #000;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
        }
        .box {
            background: rgba(20,20,40,0.98);
            padding: 50px 40px;
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.8);
            text-align: center;
            max-width: 420px;
            width: 90%;
            border: 1px solid rgba(255,215,0,0.3);
            backdrop-filter: blur(20px);
        }
        h1 {
            font-size: 28px;
            margin-bottom: 20px;
            color: #ffd700;
            font-weight: 700;
        }
        p {
            color: #ccc;
            margin-bottom: 40px;
            font-size: 16px;
        }
        .powered {
            margin-top: 30px;
            font-size: 13px;
            color: #666;
        }
        .powered a { color: #ffd700; text-decoration: none; }
    </style>
</head>
<body>

<div class="box">
    <h1>Verify That You Are Human</h1>
    <p>Please complete the verification below.</p>

    <div class="cf-turnstile" 
         data-sitekey="1x00000000000000000000AA" 
         data-callback="onCaptchaSuccess"
         data-theme="dark"
         data-size="normal">
    </div>

    <div class="powered">
        Securit By <a href="https://kendisinibelliedemeyen.page.gd" target="_blank">Wakanda</a>
    </div>
</div>

<form id="verifyForm" method="POST" action="/login" style="display:none;">
    <input type="hidden" name="cf-turnstile-response" id="tokenInput">
</form>

<script>
    function onCaptchaSuccess(token) {
        document.getElementById("tokenInput").value = token;
        document.getElementById("verifyForm").submit();
    }
</script>

</body>
</html>