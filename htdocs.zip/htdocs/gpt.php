<?php
// api/gpt.php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// Senin orijinal API'n
$original_api = "https://cvron.alwaysdata.net/cvronapi/gpt-3-5.php?prompt=";

// Prompt al
$prompt = $_GET['prompt'] ?? $_POST['prompt'] ?? '';

// Prompt yoksa hata ver
if (empty($prompt)) {
    echo json_encode([
        "reply" => "Boş mu soracan amk yarra?! Prompt yaz lan!"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // Orijinal API'den veri çek
    $url = $original_api . urlencode($prompt);
    $response = @file_get_contents($url);
    
    if ($response === false) {
        throw new Exception("Bağlantı hatası amk yarra!");
    }

    $data = json_decode($response, true);

    // Sadece reply varsa döndür, yoksa hata mesajı
    if (isset($data['reply']) && !empty($data['reply'])) {
        echo json_encode([
            "reply" => $data['reply']
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            "reply" => "AI'den cevap gelmedi amk yarra! Sunucu yattı herhalde..."
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }

} catch (Exception $e) {
    // Hata olursa bile JSON dönsün
    echo json_encode([
        "reply" => "Hata: " . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}
?>