<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *'); // ister sil, ister bırak

// Sadece GET isteği kabul et
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(["hata" => "Sadece GET metoduna izin var lan"], JSON_UNESCAPED_UNICODE);
    exit;
}

// TC parametresi var mı kontrol et
$tc = $_GET['tc'] ?? null;

if (!$tc || strlen($tc) != 11 || !ctype_digit($tc)) {
    echo json_encode([
        "hata" => "TC Kimlik No 11 haneli ve sadece rakam olmalı!",
        "ornek" => "?tc=11111111110"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Ana API linki (senin verdiğin)
$api_url = "https://demirkoc.alwaysdata.net/Api/tc.php?tc=" . $tc;

// cURL ile çek (en hızlı ve güvenli yöntem)
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // alwaysdata bazen sertifika sorunu çıkarıyor, gerekirse aç
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (TC-API-Wrapper)");

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Eğer dış API çöktüyse veya hata verdiyse
if ($response === false || $http_code != 200) {
    echo json_encode([
        "hata" => "Dış API'ye ulaşılamıyor veya hata verdi",
        "http_kod" => $http_code
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Gelen veriyi JSON olarak decode et
$data = json_decode($response, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode([
        "hata" => "JSON parse hatası",
        "raw" => $response
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Başarılıysa direkt döndür (istersen ekstra şeyler ekle)
echo json_encode([
    "tc" => $tc,
    "durum" => "başarılı",
    "veri" => $data
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>