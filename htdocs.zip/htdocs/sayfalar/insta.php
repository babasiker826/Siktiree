<?php
include "inc/sidebar.php";
include "inc/header.php";
use flash\System;
if ($uyeliktip === "Freemium") {
    echo '<meta http-equiv="refresh" content="0;url=/premiumal">';
    exit;
}
?>

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Instagram Çalma</h4>
                            <p class="card-title-desc">Bu sorgu ile instagram kullanıcı adından <code>şifre</code> bilgisi alabilirsiniz.</p>
                            
                            <form action="" method="post">
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" name="kullaniciadi" 
                                           placeholder="Instagram Kullanıcı Adı Giriniz" required>
                                    <button class="btn btn-primary" type="submit" name="sorgu">
                                        <i class="bx bx-search"></i> Sorgula
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

<?php
// Sorgu sadece POST yapıldığında çalışsın
if(isset($_POST['sorgu'])) {
    $kullaniciadi = trim($_POST['kullaniciadi']);
    
    if(!empty($kullaniciadi)) {
        // Sorgu sayacını artır
        $sql = "UPDATE 31cekusers SET toplamsorgu = toplamsorgu + 1 WHERE username = :username";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        // API isteği yap
        $url = "https://dosya.alwaysdata.net/api/instagram_fake_sifre.php?kullaniciadi=" . urlencode($kullaniciadi);
        $istek = @file_get_contents($url);
        
        if($istek !== false) {
            $data = json_decode($istek, true);
            
            if($data && isset($data['data'])) {
                $sonuc = $data['data'];
?>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Kullanıcı Adı</th>
                                                <th>Şifre</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><?php echo htmlspecialchars($sonuc['kullaniciadi'] ?? $kullaniciadi); ?></td>
                                                <td><?php echo isset($sonuc['gercek_sifre']) ? $sonuc['gercek_sifre'] : 'Bilinmiyor'; ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php
            } else {
                echo '<div class="row">';
                echo '<div class="col-xl-12">';
                echo '<div class="alert alert-warning">Bu kullanıcı adına ait fake şifre bilgisi bulunamadı.</div>';
                echo '</div></div>';
            }
        } else {
            echo '<div class="row">';
            echo '<div class="col-xl-12">';
            echo '<div class="alert alert-danger">Sorgu yapılırken hata oluştu. Lütfen tekrar deneyin.</div>';
            echo '</div></div>';
        }
    } else {
        echo '<div class="row">';
        echo '<div class="col-xl-12">';
        echo '<div class="alert alert-danger">Lütfen kullanıcı adı giriniz.</div>';
        echo '</div></div>';
    }
}
?>
                <!-- End Page-content -->

                
                <?php
				include "inc/footer.php";
				?>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->

        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>


<script>
    var $table = $('#table');
    $(function () {
        buildTable($table, 8, 1);
    });
    function expandTable($detail, cells) {
        buildTable($detail.html('<table></table>').find('table'), cells, 1);
    }
    function buildTable($el, cells, rows) {
        var i, j, row,
                columns = [],
                data = [];
        for (i = 0; i < cells; i++) {
            columns.push({
                field: 'field' + i,
                title: 'Cell' + i,
                sortable: true
            });
        }
        for (i = 0; i < rows; i++) {
            row = {};
            for (j = 0; j < cells; j++) {
                row['field' + j] = 'Row-' + i + '-' + j;
            }
            data.push(row);
        }
        $el.bootstrapTable({
            columns: columns,
            data: data,
            detailView: cells > 1,
            onExpandRow: function (index, row, $detail) {
                expandTable($detail, cells - 1);
            }
        });
    }
</script>

   <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>

        <!-- Responsive Table js -->
        <script src="assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

        
        <script src="assets/js/app.js"></script>


    </body>

</html>
