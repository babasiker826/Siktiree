<?php
include "inc/sidebar.php";
include "inc/header.php";
?>

<!-- SADECE BU SAYFA İÇİN STİL -->
<style>
    /* Hepsini sadece bu sayfaya kilitlemek için wrapper kullanıyoruz */
    .home-dashboard {
        font-family: "Poppins", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }

    .home-dashboard body {
        color: #fff;
    }

    .home-dashboard .page-content {
        background: transparent !important;
    }

    /* Arka plan */
    .home-dashboard-bg {
        background: url('assets/images/background.jpg') center center / cover fixed no-repeat;
        min-height: 100vh;
        padding-bottom: 40px;
    }

    /* Cam efekti kartlar */
    .glass-panel {
        background: rgba(0, 0, 0, 0.70);
        border-radius: 18px;
        border: 1px solid rgba(255, 232, 124, 0.8);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.8);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        margin-bottom: 18px;
        position: relative;
    }

    .glass-panel::before {
        content: "";
        position: absolute;
        inset: 0;
        border-radius: inherit;
        border: 1px solid rgba(255, 255, 255, 0.03);
        pointer-events: none;
    }

    .glass-panel-header {
        font-size: 15px;
        font-weight: 600;
        letter-spacing: 0.04em;
        color: #ffe55b;
        text-transform: uppercase;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .glass-panel-header i {
        font-size: 16px;
    }

    .announcement-label {
        font-size: 13px;
        color: rgba(255, 255, 255, 0.60);
        margin-bottom: 4px;
    }

    .announcement-value {
        font-size: 14px;
        font-weight: 500;
        color: #fff;
    }

    .announcement-box {
        border: 1px solid rgba(255, 232, 124, 0.4);
        border-radius: 12px;
        padding: 10px 12px;
        background: rgba(0, 0, 0, 0.40);
    }

    .text-soft {
        color: rgba(255, 255, 255, 0.70) !important;
    }

    /* Profil / Radyo alanı */
    .profile-radio-wrapper {
        align-items: center;
        gap: 18px;
    }

    .profile-username {
        font-size: 20px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 999px;
        background: rgba(0, 0, 0, 0.65);
        border: 1px solid rgba(255, 232, 124, 0.7);
        display: inline-block;
        margin-bottom: 4px;
    }

    .profile-message {
        font-size: 13px;
        color: rgba(255, 255, 255, 0.75);
    }

    .radio-title {
        font-size: 14px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #ffe55b;
        margin-bottom: 8px;
    }

    .metric-title {
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: rgba(255, 255, 255, 0.55);
        margin-bottom: 4px;
    }

    .metric-value {
        font-size: 18px;
        font-weight: 600;
        color: #fff;
    }

    .metric-box {
        border-radius: 14px;
        background: radial-gradient(circle at top left, rgba(255, 232, 124, 0.25), rgba(0, 0, 0, 0.70));
        padding: 10px 14px;
        border: 1px solid rgba(255, 232, 124, 0.35);
    }

    .btn-music {
        border-radius: 999px;
        padding: 7px 20px;
        border: none;
        background: linear-gradient(135deg, #ffe55b, #ffb347);
        color: #000;
        font-size: 13px;
        font-weight: 600;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.8);
        transition: transform .15s ease, box-shadow .15s ease, filter .15s ease;
        white-space: nowrap;
    }

    .btn-music:hover {
        transform: translateY(-1px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.9);
        filter: brightness(1.05);
    }

    /* Sayaçlar */
    .stat-pill-card {
        background: rgba(0, 0, 0, 0.75);
        border-radius: 18px;
        border: 1px solid rgba(255, 232, 124, 0.6);
        padding: 16px 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 10px;
        gap: 10px;
    }

    .stat-pill-title {
        font-size: 13px;
        color: rgba(255, 255, 255, 0.65);
        margin-bottom: 4px;
    }

    .stat-pill-number {
        font-size: 20px;
        font-weight: 600;
    }

    .stat-pill-icon-wrap {
        width: 54px;
        height: 54px;
        border-radius: 999px;
        background: radial-gradient(circle at 30% 0, rgba(255, 232, 124, 0.65), rgba(0, 0, 0, 0.9));
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 0 25px rgba(255, 232, 124, 0.6);
    }

    .stat-pill-icon-wrap i {
        font-size: 26px;
        color: #000;
    }

    /* Sohbet kutusu */
    .chat-panel {
        border-radius: 18px;
        border: 1px solid rgba(255, 232, 124, 0.7);
        background: rgba(0, 0, 0, 0.80);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.9);
        margin-bottom: 18px;
    }

    .chat-panel .card-title {
        font-size: 17px;
        font-weight: 600;
        color: #ffe55b;
        margin-bottom: 12px;
    }

    #chat-container {
        max-height: 260px;
        overflow-y: auto;
        padding: 10px;
        background: rgba(0, 0, 0, 0.6);
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.06);
        margin-bottom: 10px;
        font-size: 13px;
    }

    /* Log alanı */
    .log-panel-title {
        font-size: 17px;
        font-weight: 600;
        color: #ffe55b;
        margin-bottom: 10px;
    }

    .verti-timeline .event-list {
        padding-left: 0;
        margin-bottom: 14px;
    }

    .verti-timeline .event-timeline-dot i {
        color: #ffe55b;
    }

    .log-time {
        font-size: 12px;
        color: rgba(255, 255, 255, 0.65);
    }

    /* Küçük uyarlamalar */
    @media (max-width: 991.98px) {
        .profile-radio-wrapper {
            flex-direction: column;
            align-items: flex-start;
        }

        .metric-box {
            margin-top: 12px;
        }
    }
</style>

<div class="home-dashboard">
    <div class="main-content home-dashboard-bg">

        <div class="page-content">
            <div class="container-fluid">
                <!-- PROFIL / RADYO PANELİ -->
                <div class="row">
                    <div class="col-12">
                        <div class="glass-panel p-3 p-md-4">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div class="radio-title">Wakanda Sorgu Paneli</div>
                                <button class="btn-music">
                                    #SİKER
                                </button>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="d-flex profile-radio-wrapper">
                                        <div class="flex-shrink-0">
                                            <img src="<?= $profil ?>" alt="profil" class="avatar-md rounded-circle img-thumbnail" style="border:2px solid rgba(255,232,124,0.8);box-shadow:0 0 20px rgba(0,0,0,.9);">
                                        </div>
                                        <div class="flex-grow-1 mt-3 mt-lg-0">
                                            <h5 class="profile-username" style="background: url('<?= $backgroundpic ?>') center / contain no-repeat; color: <?= $isimcolor ?>;">
                                                <?= $username ?>
                                            </h5>
                                            <div class="profile-message">
                                                <?php
                                                $mesajlar = [
                                                    "Yinemi sen amk",
                                                    "Hoş geldin la yarram",
                                                    "Çok kalma git sorgunu at çık",
                                                    "Biz yapay zekayız kardes gerizekalı değiliz",
                                                    "Zoruna gidenin borusuna girsin.",
                                                    "Göt adamsında özledim be seni",
                                                    "afferin, gözüme giriyorsun"
                                                ];
                                                $rastgeleIndex = array_rand($mesajlar);
                                                echo $mesajlar[$rastgeleIndex];
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6 mt-4 mt-lg-0">
                                    <div class="row g-3 text-center text-lg-start">
                                        <div class="col-4">
                                            <div class="metric-box">
                                                <div class="metric-title">Sorgu sayısı</div>
                                                <div class="metric-value"><?= $sorgusayisi ?></div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="metric-box">
                                                <div class="metric-title">Kalan gün</div>
                                                <div class="metric-value"><?= $süre ?></div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="metric-box">
                                                <div class="metric-title">Üyelik tipi</div>
                                                <div class="metric-value"><?= $uyeliktip ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- row -->
                        </div>
                    </div>
                </div>

                <!-- SAYI KARTLARI -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="stat-pill-card">
                            <div>
                                <div class="stat-pill-title">Kullanıcı sayısı</div>
                                <div class="stat-pill-number"><?= $kullanicisayi["toplam"] ?></div>
                            </div>
                            <div class="stat-pill-icon-wrap">
                                <i class="bx bx-user"></i>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="stat-pill-card">
                            <div>
                                <div class="stat-pill-title">Premium sayısı</div>
                                <div class="stat-pill-number"><?= $kullanicisayi["premiumsayisi"] ?></div>
                            </div>
                            <div class="stat-pill-icon-wrap">
                                <i class="bx bx-user-check"></i>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="stat-pill-card">
                            <div>
                                <div class="stat-pill-title">Banlı kullanıcı sayısı</div>
                                <div class="stat-pill-number"><?= $kullanicisayi["banlisayisi"] ?></div>
                            </div>
                            <div class="stat-pill-icon-wrap">
                                <i class="bx bxs-error-alt"></i>
                            </div>
                        </div>
                    </div>
                </div>

              
                <!-- LOG PANELİ -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="glass-panel p-3 p-md-4">
                            <div class="log-panel-title">WAKANDA Log</div>

                            <?php
                            $baglan = $db->query("SELECT * FROM `31ceklogs` WHERE username = '$username' ORDER BY `tarih` DESC LIMIT 5;");

                            while ($veri = $baglan->fetch()) {
                                $logstype = $veri['type'];
                                $kullaniciadi = $veri['username'];
                                $tarih = $veri['tarih'];

                                if ($logstype === 1) {
                                    $titlelog = "Giriş logu";
                                    $icon = "bx bxs-log-in-circle";
                                } elseif ($logstype === 2) {
                                    $titlelog = "Çıkış logu";
                                    $icon = "bx bxs-log-out-circle";
                                } elseif ($logstype === 3) {
                                    $titlelog = "Sorgu logu";
                                    $icon = "bx bx-search-alt-2";
                                } elseif ($logstype === 4) {
                                    $titlelog = "Multi Denemesi";
                                    $icon = "bx bx-no-entry";
                                }
                                ?>

                                <div data-simplebar style="max-height: 376px;">
                                    <ul class="verti-timeline list-unstyled">
                                        <li class="event-list">
                                            <div class="event-timeline-dot">
                                                <i class="bx bx-right-arrow-circle font-size-18"></i>
                                            </div>
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar-xs">
                                                        <div class="avatar-title bg-primary-subtle text-primary rounded-circle">
                                                            <i class='<?= $icon ?> font-size-20'></i>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="flex-grow-1">
                                                    <div>
                                                        <?= $titlelog ?>
                                                        <p class="log-time mb-0"><?= $tarih ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                            <?php } ?>
                        </div>
                    </div>
                </div>
<!-- ULTRA AKICI + ORTADA LOGO DÖNEN + SİM SİYAH PRELOADER -->
<div id="preloader">
    <div class="logo-spinner">
        <img src="assets/images/eze.png" alt="Logo" class="eze-logo">
    </div>
</div>

<style>
    #preloader {
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: #000000; /* Simsiyah */
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: opacity 1s ease-out, visibility 1s ease-out;
    }

    #preloader.hide {
        opacity: 0;
        visibility: hidden;
    }

    .logo-spinner {
        width: 120px;
        height: 120px;
        animation: rotate 2s linear infinite;
        filter: drop-shadow(0 0 30px #FFD700);
    }

    .eze-logo {
        width: 100%;
        height: 100%;
        object-fit: contain;
        border-radius: 50%;
        border: 3px solid #FFD700;
        padding: 8px;
        background: rgba(0,0,0,0.8);
        box-shadow: 
            0 0 40px rgba(255,215,0,0.6),
            inset 0 0 30px rgba(255,215,0,0.2);
    }

    @keyframes rotate {
        from { transform: rotate(0deg); }
        to   { transform: rotate(360deg); }
    }

    /* Ekstra akıcılık ve premium his için */
    #preloader::before {
        content: '';
        position: absolute;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(255,215,0,0.15) 0%, transparent 70%);
        animation: pulse-ring 3s ease-in-out infinite;
    }

    @keyframes pulse-ring {
        0%, 100% { transform: scale(0.8); opacity: 0.6; }
        50% { transform: scale(1.3); opacity: 0.2; }
    }
</style>

<script>
    window.addEventListener('load', function() {
        setTimeout(function() {
            document.getElementById('preloader').classList.add('hide');
        }, 1200); // 1.2 saniye sonra ultra yumuşak kaybolur
    });
</script>
            </div> <!-- container-fluid -->
        </div> <!-- page-content -->

        <?php include "inc/footer.php"; ?>

    </div> <!-- main-content -->
</div> <!-- home-dashboard wrapper -->

<audio class="auto-play" autoplay loop>
    <source src="babapro.mp3" type="audio/mp3">
    Tarayıcın ses desteklemiyor.
</audio>

<!-- JS -->
<script src="assets/libs/jquery/jquery.min.js"></script>
<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/libs/metismenu/metisMenu.min.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script>
<script src="assets/libs/apexcharts/apexcharts.min.js"></script>
<script src="assets/js/pages/saas-dashboard.init.js"></script>
<script src="assets/js/app.js"></script>

</body>
</html>
