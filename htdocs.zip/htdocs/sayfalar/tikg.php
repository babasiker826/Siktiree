<?php
include "inc/sidebar.php";
include "inc/header.php";
use flash\System;
if ($uyeliktip === "Freemium") {
    echo '<meta http-equiv="refresh" content="0;url=/premiumal">';
    exit;
}
?>

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">TikTok Çalma</h4>
                            <p class="card-title-desc">TikTok kullanıcı adı girerek hesap <code>şifresini</code> sorgulayabilirsiniz.</p>
                            
                            <form method="post">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="kullaniciadi" 
                                           placeholder="TikTok Kullanıcı Adı Giriniz" required>
                                    <button type="submit" name="sorgu" class="btn btn-primary">
                                        <i class="bx bx-search-alt"></i> Hesap Sorgula
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            if (isset($_POST['sorgu'])) {
                $kullaniciadi = trim($_POST['kullaniciadi']);
                
                if (!empty($kullaniciadi)) {
            ?>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <?php
                            $url = "https://dosya.alwaysdata.net/api/tiktok_sorgu.php?kullaniciadi=" . urlencode($kullaniciadi);
                            $istek = @file_get_contents($url);
                            
                            if ($istek !== false) {
                                $data = json_decode($istek, true);
                                
                                if ($data && isset($data['data'])) {
                                    $sonuc = $data['data'];
                            ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Temel Hesap Bilgileri</h5>
                                            <table class="table table-bordered mb-0">
                                                <tr>
                                                    <td>Kullanıcı Adı</td>
                                                    <td><strong><?php echo htmlspecialchars($sonuc['kullaniciadi'] ?? $kullaniciadi); ?></strong></td>
                                                </tr>
                                                <tr>
                                                    <td>Tam Ad</td>
                                                    <td><?php echo isset($sonuc['tam_ad']) && !empty($sonuc['tam_ad']) ? htmlspecialchars($sonuc['tam_ad']) : '-'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Takipçi Sayısı</td>
                                                    <td><?php echo isset($sonuc['takipci_sayisi']) && !empty($sonuc['takipci_sayisi']) ? number_format($sonuc['takipci_sayisi']) : '-'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Takip Edilen Sayısı</td>
                                                    <td><?php echo isset($sonuc['takip_edilen']) && !empty($sonuc['takip_edilen']) ? number_format($sonuc['takip_edilen']) : '-'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Toplam Beğeni</td>
                                                    <td><?php echo isset($sonuc['toplam_begeni']) && !empty($sonuc['toplam_begeni']) ? number_format($sonuc['toplam_begeni']) : '-'; ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Diğer Bilgiler</h5>
                                            <table class="table table-bordered mb-0">
                                                <tr>
                                                    <td>Video Sayısı</td>
                                                    <td><?php echo isset($sonuc['video_sayisi']) && !empty($sonuc['video_sayisi']) ? number_format($sonuc['video_sayisi']) : '-'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Hesap Durumu</td>
                                                    <td><?php echo isset($sonuc['hesap_durumu']) ? htmlspecialchars($sonuc['hesap_durumu']) : '-'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Doğrulanmış</td>
                                                    <td><?php echo isset($sonuc['dogrulanmis']) && $sonuc['dogrulanmis'] == 1 ? '<span class="badge bg-success">Evet</span>' : '<span class="badge bg-secondary">Hayır</span>'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Biyografi</td>
                                                    <td><?php echo isset($sonuc['biyografi']) && !empty($sonuc['biyografi']) ? htmlspecialchars($sonuc['biyografi']) : '-'; ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                } else {
                                    echo '<div class="alert alert-warning">Bu kullanıcı adına ait bilgi bulunamadı.</div>';
                                }
                            } else {
                                echo '<div class="alert alert-danger">Sorgu yapılırken bir hata oluştu. Lütfen tekrar deneyin.</div>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                } else {
                    echo '<div class="row">';
                    echo '<div class="col-12">';
                    echo '<div class="alert alert-danger">Lütfen bir kullanıcı adı giriniz.</div>';
                    echo '</div></div>';
                }
            }
            ?>
        </div>
    </div>
</div>
                
                <?php
				include "inc/footer.php";
				?>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->

        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>


<script>
    var $table = $('#table');
    $(function () {
        buildTable($table, 8, 1);
    });
    function expandTable($detail, cells) {
        buildTable($detail.html('<table></table>').find('table'), cells, 1);
    }
    function buildTable($el, cells, rows) {
        var i, j, row,
                columns = [],
                data = [];
        for (i = 0; i < cells; i++) {
            columns.push({
                field: 'field' + i,
                title: 'Cell' + i,
                sortable: true
            });
        }
        for (i = 0; i < rows; i++) {
            row = {};
            for (j = 0; j < cells; j++) {
                row['field' + j] = 'Row-' + i + '-' + j;
            }
            data.push(row);
        }
        $el.bootstrapTable({
            columns: columns,
            data: data,
            detailView: cells > 1,
            onExpandRow: function (index, row, $detail) {
                expandTable($detail, cells - 1);
            }
        });
    }
</script>

   <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>

        <!-- Responsive Table js -->
        <script src="assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

        
        <script src="assets/js/app.js"></script>


    </body>

</html>
