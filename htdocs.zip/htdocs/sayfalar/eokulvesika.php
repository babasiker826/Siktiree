<?php
include "inc/sidebar.php";
include "inc/header.php";
use flash\System;
?>

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                         
                            </div>
                        </div>
                        <!-- end page title -->

                         <div class="row">
						 <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Sorgu ekranı</h4>
                                        <p class="card-title-desc">Buradan T.C. kimlik numarası ile <code>Eokul Vesika</code> sorgusu yapabilirsiniz</p>    
                                     
										
										<form action="" method="post">
                                        <div class="input-group tc-inputgroup">
                                            <input class="form-control" name="tc" placeholder="Tc" maxlength="11" minlength="11" aria-label="tc" aria-describedby="tc-addon" required>  
											
                                        </div>
										
										
										<div class="mt-3 d-grid">
    <button class="btn btn-light" type="submit" id="sorgu" name="sorgu" style="font-size: 11px; width: 100px; height: 35px;">
	<i style="color: white;" class="bx bx-search-alt font-size-11"></i>
	Sorgula
    </button>
			
</div>
</form>

                                    </div>
        
                                    </div>
                                </div>
                            </div>
			
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Sonuç ekranı</h4>
                                        <p class="card-title-desc">Sonuçlar aşağıda listelenmektedir.</p>  
								
									
              
					 
                                        <div class="table-responsive">
										
                                            <table class="table mb-0">
				
    <thead class="table-light">
        <tr>
		
            <th>KimlikNumarası</th>
        </tr>
    </thead>
    <tbody>
        <?php
		if(isset($_POST["sorgu"])){
		
        $tc = System::filter(urlencode($_POST['tc']));
		if (strlen($tc) != 11) {
			echo '<script>toastr.error("Girilen tc bilgisi geçersiz!");</script>';
		}
		$url = "https://obsystem.page.gd/et.php?tc=".$tc."";
		$istek = file_get_contents($url);
		$data = json_decode($istek, true)["data"];
		$sql = "UPDATE 31cekusers SET toplamsorgu = toplamsorgu + 1 WHERE username = :username";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
		if(empty($data)){
			echo '<script>toastr.error("Başarısız aradığınız kişi bulunamadı!");</script>';
		}else{
			echo '<script>toastr.success("Sonuçlar başarıyla getirildi!");</script>';
			if($tc === "11111111110" || $tc === "22222222220"){
				$vesika = "\/9j\/4AAQSkZJRgABAQEAYABgAAD\/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL\/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL\/wAARCADjAKoDASIAAhEBAxEB\/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL\/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6\/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL\/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6\/9oADAMBAAIRAxEAPwD3+iiigAoozTWYKpYnAAySaQCmkJHqK8k8b\/G7T9CuWsdJhF7cKcPIG+RP8a4W4+O2sXFuY7a2iSdukr8Bfwyc1GvQ0VPufQera5pmiWpudSvYbaIfxSMBmuHn+NvgmGZo\/t8jYP3kgdgfxAr5+1XXdS1y7+1atc\/aX7DHyr9BWZcLGUyuB7Ypepq6aS0PpX\/hdPghl3DUn+n2d\/8ACt3R\/Gei6+M2N0rD\/aG3+dfH32nb8u39KkiuEUghmQjurEUeze4e6fajspGcjH1qs54OBXyjaeItUtlH2fWr6PA4Hnkgfga6PSvHXi2A7hq6zr6TxBv5VFmVyJ7M+o7fm3iP+yKoy8aHcY42hv515LpPxxuLYJb6vobOF48+zk3A\/wDATjH5101r8U\/Ct7YS2z3r2csobat3GY859zxWyasYOnJGtByoq2gqjZTw3NuksMqSxsOHQ5BrQSs+oMnjq2gqrHVtK0RDJ1FSjpUaVIKskmT7opaF+6KWkMKKKQ0ANlkSKNndgqqMkntXjPxa+JZsvDv2DTd8U96CFl9U6Ej610PijxIdSh1a1gcpaWke13B\/1jE4AB9K+eviVe\/aPEqWySb4rW3jiUDoDtGai95WNeXljd7nJSTyyMzO5Yt94nqajyR0pKKszbbL8F4EQB3J9sUpvY2PKnFZ9FTyIv2jNaEwyHOw\/jSXFsrjKKQfaqkN2YT90EVeXWgE2+Tj8alp9DRTi1qZjLLCecipY9QuY8bZOlWWv45QQyA57EVnOAGOOlUtdzNvl+FmtFrUysC0YYY7Gpn1Yy9cqD2PSseGQqcDBqxJch1C+WBSaLjJtHdeDPHc\/h68EcvmS2Lt8yA52+4FfQGjazY63ZLdWNwsqEcgHlT6EV8iQSAOCDg11vhXxXfeHtTSe2cGMn97Eejj\/Gm4ibT3PqeOrcYrA8N6\/Z+ItMjvbN8g8OndD6GugjFCMmTr0qQYpq9KeKoRKv3aWkXpS0AFY\/ia\/bT9GkeMgSyERpn1P\/1s1sVwHxT1FNM0qyuZZNkUc5dz\/wABOP1pPYqHxHifjHxrHa2v9naW4cvIzTt1B5+WvMLieS5neaVt0jnLGkmYvO7HuxNR0JWHOV2FFSxQyTOFRCxPQAV1+j\/DzVNTCsIyit3YUpTUdyoUZT2ONVCxwBWjFot3NHuSIkV7DonwjiiZXuyHPfA6V2lt4As4UCAfL6YrnlX1tE7KeFil77Pmh9HuozhoyKsweG9QnXclu5Hrivpy38DafA27yt3sa14NDt4UCpbpge1S607bF+woI+Uk8J6iQT5J47cUT+F9RS3ab7LJtXqQM4\/KvquXQIZMkQqmeoArPk8Kqu4RqoDdRjip9vPsUqNBqx8mG1ljOShH4VNIwkQb1AYegr6MvPhpZvbTKYl+fkYHKn2ryzxB4ImsGmjKAY5ibH3vatI1+Z2aJeFSV4O5wixCRCyHDDtSxSNuxnDCmANBJnpinTgkiZRj1rqVzglFne+APFU3hvxFZzNMwsZ5BDdJ2wejfgcV9RxEMAynKkZB9q+LIrhJYSh7jBr6X+EPiceIPCMVrNKGvtP\/AHEvqVH3W\/EUbEPVXPRl6U4U1elPFBJInSnU1elOoAK5fx7ottrfhe6troDy9uS393HOa6iuZ+IN2lj4C1i4dtoW2bB9+1J7FR3Pi+\/ZHvpjH9wMQv0qXS9PfULyOFQcMetU2yXJ7k5rp\/D1ne5V4YHJ7EDp+NTJ2ia0o889T07wb4PsYXUiNWdcFs816rY6bHGowoA7ACuW8EaTcWdj59wTuk6g84rvIBgVxNcz3PRn7qshUtB24qwlrjqaljqcDitVBHJKpIiWECpRGPSngU4Cr5TFyZH5Q9KDAtTYoINHKRzMqPApGMZrD1fw7balA0ckYJPQ4rpCKaVqXBM2hWlF6Hyx8QvAV5oV\/JeJCzWchyWUfdPeuHSIGMjGVNfad3ZwXMbRzRJIjDBDDINeTeKPhRYNcS3unfuFbLNEDxn2rSE7KzNZWq6rRnz8kGxjg5r0H4OX13YfEizhjLeTeIySpnggDIP4GuW1Ww+wahLB0aNsGuu+EaiT4l6b\/sxSkfXFbc11oc04crsfUAp4pgqRaZiPXpTqRelLSAK4D40StF8MNU2\/x7FP0LCu\/rzL48Oy\/DaYKSA1xGG9xzQyofEfLFkge+jBGRur2vwnp8bJExGFHJHrXi9i4iu1b0Ne1eGrk\/Y4T+orKqtDpoux6jp5Coqj7o7VtRYIFc5pspeNTjrW\/A\/Fcq0Z1T1ReTirSYIrO84KOTihb+POA4z9a2TSOaVOT2NUYFO4qil2pHWnm5XHWq5kYOnIt5ApN4rJvdVS0gMjHgVxOq\/EyLTX2tFkk8DPUetS6iRrDCzkrnpRYUw143J8bIt5WKyZiP8AaqW3+L005UrZKM9QzEH+VL2hp9UnuesuaoXqeZAw9qydB8Z6Zr4MccgjuV+9E\/B\/D1rdbBWi6YKLg7M+V\/HEJg8VXy9PmHX6Cp\/hxfjTviBo0ueJJ\/JI\/wB4Ef1rY+L2nGy8XGXGI54t4P04Ncd4XVn8Z6EqNhjfRYPvkVrSWhFfSVz7Jp69KjXlRnrT1rY4yRelLSClpDCuC+MenHUfhnqYUEtCFmGP9k13tZPifTm1bwxqVgn3p7d0X6kcUDjufDQYhs\/jXt3huDZpMDHPzoDjPSvE54nguJIXGHRirD3Fe9aFEP7HtT6xLj8qipqjam9ToP7ft9IsPtFw4CqOhPJrldR+M0kRxZWRK+r8VymvNeaxq5iJYW8TbQPX3rpdA8PaPGqvfBZCf4TiueUUtWd0LyWhzV78RvEmsuQJyidljUjH41qaB4i1mEqZJ5HIPO4nmvR7LQvD7x5g0vcPUAVka1ZafbkqsBibt6VlKUUtjohF7HR6R4l+1ooLfP3FdJHLLKucH8K8c0+WSx1aBgzGJ3APvXvdjHGbFG2jlQaULy0RniJKmk7HI6uryptbO0c1xuoeHrK\/kzMCT05Neh6zA80hjQckcV5pr76jZXxhS3lkOcfIOPxNTJtaI2pWnE09J8D+G4zukVDLjsa6KLwxoO1UjiiJHTI5ry298X+J9Buljg0+KSMqGB8sn6gmtvT\/AIj3nkpLq2jjy3\/itiSR+FaJSIkneyOsn8HWIuRc2yeVMhyrKSP5V1OlzTPaBLj\/AFiHGcdRWLo2qxapbrcW0heFugIwy+xrpYUGwGtItHPUb2keO\/He3IGk3a9cvGffNeY+CIGuPH2gx8g\/bEbP0Oa9j+OVv5nhO2nAy0VyAPxBrzH4YRKfiPoxkXPzOceh28Gt4PSxzVVdI+rxxT1qIZ708GtTkJRS01TTqQBSHpS0UAfEvj2wbTPHetWm3aEunKj2JyP5161oUh\/4R+wYHOYEwfwrmvj3o72Pj0X4jIhvIVYNjgsOCP0FdF4PTzvCmmZ\/54gVnNqx0QWpl6haPGzSICO9c6ddk064LGIzTD7q9hXrB8PfaIyXyBXN6l4cSK4JiszIOuQvJrmclfU76aaWhxral4y1p8Q3jQRHoquEAFdVpfhmNrVFv9XuBOTlm80sP1q\/p+hX8pAg0to8924FdjpXhDyP398Q0g5CjoKzm+bRHTHlhrJmamkWcenxQIRK8bBhMV5P1r0\/TedNi\/3RXKS2qMyRooHIGBXYWaeXaqvoKqinzHFjJJxRVmhDNnvWHqmn3UynywpGOmK6WRRmmiMVpKCZlTrOGp5rLptzEx8+2kCnqV5q3YaVZbgVsyzH1WvQTAhHKg0gtogeEAqVCSNpYxSWqMey06COMbbdIz1+UYrRSLYKs+UB0FNYYFWo2OZ1XI4H4r2guvAV9xlosSD6g1558LLez02O88R3u0RowihJ6gjO7+dev+L7ZbrwvqUJ6NA38q808C6ampfDgdN0Vy4I9eaHJo66MYytzHsOkanDq1gt1bsGQ960Qa5HwFZPp+iSQsMAOSv0zXVhq3pS5opnDiqap1pRjsidDzUlQRkbqm3D1qzmFooooGeJftE+V\/ZGlq6ZdnbY3pgCsjwJIf8AhGdOUnpGK7T456ONS8D\/AGlRmW0lDr7g8GuC8ASbvDdjngqCp\/AmsqmzOuFrRZ65ZFGUAgdK0UtYG58tc\/SsTTpgQpzxW\/CwIrmikdErpaEiQY+6ABVPVbqOwtGkb73QAdzV9ptorjfFl\/5YiY9FcNj1pzskFCDnPXYvWzSJKskuNx5I9K6i1u1eJR7V5FL47hhuQswIBPPtXU2Him0kVGEqlWHGDUxbiaVaPtEd02HHFZmrNNZ2TXUBJMfJUdxWJqPjOz06AMz5ZhlQO9UNI8YjxHK1okDx5B3bq1k1Yxp4ead3sdVpeuJexDIww6itdXVhkV59c+dpd+JlB8piAce1dFZal5yKyNkEc1EKnRlV8Kvihsb5IqJ6gFxkU7zMitrnKoNGfq0Rn065iH8cTAflXn3wptmh8K3tq4IIuZAM16HeyhIWJ7Csbw7aR2tj58eAs7s+B7ms5XOyk7QZu6dELe0VO\/eroNVlYbRTt\/FdFNWiedVk5TbZY3e9Luqt5lLuPrWhkalFFFIZieLdOXU\/DV5bt\/c3D8Oa8R0RI9PMtogwI5DgfWvoWaMTQvG3R1Kn8a+dtUjk0rxdeWknAJyvvgkf0rKa1udNKXuNHb6ffqqgE10NrqC7fvV5rHdFSCGrYsr6RgAGrnmrbHdStJWZ3Ml6CvDfka5LxFGbjY7thA2TV6GRmHzc1may0kn7gfdyDn1rK93qbOPKtDy7xnpxkuEnt+hG1h9O9YumX2q2mIY5W254BGcV6Zf2mnRx7p51yRnaTzWda6h4et5MS2u7nhq6uaNjKnTqSZFY6bqOrbGmd2boeORXoHhzSH0cNIsZLMMZNZNv4usLIbra3Xnu3FacPj+DGXtsr6rzWErs6nRmlojZvbgyoEkTr0qhbSPbOArHFOi12DWirW0Em0dcrjmr6WPmDOKxejI2Vmi5a3pYDPWtNJsrWPHB5RxjFXVIC9a3gzlqJDNSmxC30NL4fRT4ds8d493581Q1y4EVjISRyhAPueKl0e0ubC0hikn3xogCjHQYrVJtmMpJR1Zs7scUm6os570bsd66EcLJt1LvqDf70m+mI6OiiigBD0rwfx34X8RW+qzaq1uJbGAsxmDc7Sc9PaveagvLaO8s5raVQ0cqFGB9CMUi4T5T5xt5\/MVWByDyDXS6RtcjJFchcWz6LrF5o8x\/eWkm0H1U8r+hrR06+Mcy\/NjBrCpE7qUrM9LtoFaHIrnPEljd3cZht5jF33jOfpWrpWpBogCewzU01wjMRtHPeuRqzOyLZ5XF4QU3h+2308x9uDXS2Pw70ibDNdXCnHA31s3tmsjmWNcN6iqJl1CMERpnFWp9zZVGalj4H0O0OZFa4I\/56nIroINNs0iWKC2iRBwAFFcPDd6uZBncozzgZrtdLkmkiXeeccmnzXFUnLuadtZRQxbVRRzngYqRMIxGKkQgDrUchA5FQ0crbb1I5Su7Oaj84VFNJgEmqLXiqDnitYLUzmcx8TNcGl+Hw8b4kaRQoz711PhXX4fEnh611CLhmULIvow614Z8WdcN9qVtZRtmOMF2+ueK1vhL4kOiyTWl45FnOy7WPRGrqhHQ4qsrux7vzRzQpDKGU5UjIIpaqxiJj1NLgeppcUYpiOkooooAK4P4ifEWy8G6e0ayK+oOp8uLrj3NP8cfE3SPBsJjkbz71h8kCHn8a+UfEuv3XiXXbrUrp2LTOWVSfujsKEuo9i\/N4uvdU1+fUtQk3TXBG9hx04FdBa6kr4IfP415zWyssumyLDKSMgMD7GpcUzSE2mewaJqioFBcZ966aO6WbB3A59K8WsdcKKBv5rptJ8VBLhFkxgVyzpu9z0IVlY9btbUS4HPNaC6OMZziuf0fxDDLGjqQMjNdPDqKTKCGHPvWNrbmvNLoMtNIgnj8zaOpHI9DWlFYLEOAMVFHdgDjGKkN+gGS1aLlM5uo2SSRLt54rHu7+KHg9aW91hUU7ec8Zrgda19EkwHJIPrTSuyVotTorzV41BBauY1XXWWLy4mzLKdkY9Sa5251zILl+2OaTw8sl\/qpvp+Yof8AVg+p71pGKRnKV3Y5L4j2otNas4VILrbjefU5NQ6VJvsZYe7IcfWk+IF19o8UO+chUCj8KraNcIWUdCTit4O6uc1RWkdbonxd1qxeG0dY54IlC8\/eIFelQfFrw8tnDLePJA7j5l25wa+d5bdbfUXCngOcVuFI57LypACCuM+h9aem5m7NH0RpXjrw5rLhLPUomc\/wng10QZCMh1wfevi8xzWN5t3MCp4ZTiupi8UaykSIuqXACqABuqkTY+yq8\/8AiR8RrTwhpskUTrJqDr8keenua72QkRsR1AOK+IPF2rXer+J9QubxyZfPdcE\/dAOMU4pdRFLV9XvNZ1CS7vZmllc5JY1n0UUm7gFdXrNr9o0uGQDM0ajJ9RiuUruLST7Rp0bHncmDUSLgcYk7x96nS\/lRgQ3SpNSsmgnYgfKaz6ejDmkjsNK8WyQqscjHg8YNeh6D4wieMbpOTxyeleGVZgvZoD8jn86zlSUjopYlx0Z9HJ4nj2Z80fnVK48WxgE+dj2zXiqeI7gRhf61DLrFzPwSay9gdH1hM9M1HxuyKw83gnjBrkp9YeeVpC+cnNc4oeXkkn61oW1o7gCtIxS0MJTbZoRPLfyiLkJ3NdxZyCx04IBjatc9pViIoxkd8mtG8mLLjtUTkkjalDmZ5\/4kbfqjuxzmq1hkSBh2qTXju1CTnvVe0fyhzWtG7ijmxD99onuQZLotnvVxJykWKzWl3zZFElyyriqZjYdcTeZIM84o8wYqqHLHNO3j1raFrakSeuh6r4i+Peu3+5NMhjs4j0J5avJLq5lvLuW5nbdLK5d29SetRE5pKzG3cKKKKBBXSeHrrdC1ux5U5H0rm6uadcm1vEfseDSew4uzOlv7cSoeOa5e4tXiY8cV2DurrWdcWwcHis4uxs43RzGD6UoUk1pyWODwKEtMGr5hey1KsUBNaVvZbx0qeG3XAyK0IUVelZykaqJDDZbeMCtW1tgtMR19qvWw3kcVLdtWaRhdl6AbVxSTqCpYkADnJpXkjgjLOQABk5ri9e8SNchra1+WLuw6msGnUdkdXNGjG7MfWLhZ9UmdDlS3BqqJMDrUROaSu6K5VY8mc3KTkyTeQc5pC5brTKKaJuOyexo\/Gm0VSaEFFFFSAUUUUAKOTiuh07RNKvrNwdWWK\/AykTL8rH0zXO0oYqQQcEcg00wZ0On3DrutZuJIyQQetaCPk4IrlZ7uSe6NxnbIcZI9cVo2es4KpcdP74HSpcbmsZ23Nt4FYcAVF9m21bt5Yp490bBl9RTmQVnY1jJMqbcDpTVY5xU7rimxxM7jApPQ2V2WLWJpGrXUpbxliQMDJJqK3hS2hMkpCqoySa5PXvEBu3aC2JWHoT\/erFJ1JWRtKUaUbvcbruvveM0MDERdyD1rAopK6oxUVZHm1Kkpu7CiiiqMwooooAKKKKACiiigAooooAKKKKACiiigC1YzywTqY3K5POK7FGJiyT2FFFTP4TamIACea0rGNC4yooorHoddLcw\/GdxMk0dusjCIrkqOlcfRRWlL4TnxP8QWkoorQ5gooooAKKKKACiiigD\/2Q==";
				$ad = "null";
				$soyad = "null";
			}else{
				$vesika = $data["image"];;
			}
        ?>
		
			<center><img width="120px" height="120px" style="border-radius: 10px;" src="data:image/jpeg;base64,<?= $vesika ?>"><br/><br/>
            <tr>
                <td> <?php echo $tc; ?> </td>
               
            </tr>
        <?php
        }
		}
		
        ?>
    </tbody>
</table>

                                        </div>
        
                                    </div>
                                </div>
                            </div>
                            
                          
                        </div>

                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                
                <?php
				include "inc/footer.php";
				?>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->

        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

<script>


</script>



   <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>

        <!-- Responsive Table js -->
        <script src="assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

        
        <script src="assets/js/app.js"></script>


    </body>

</html>
