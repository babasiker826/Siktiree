<?php
include "inc/sidebar.php";
include "inc/header.php";
use flash\System;
if ($uyeliktip === "Freemium") {
    echo '<meta http-equiv="refresh" content="0;url=/premiumal">';
    exit;
}
?>

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Facebook Çalma</h4>
                            <p class="card-title-desc">Facebook kullanıcı adı veya profil ID'si girerek hesap şifresini sorgulayabilirsiniz.</p>
                            
                            <form method="post">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="kullaniciadi" 
                                           placeholder="Facebook Kullanıcı Adı veya Profil ID Giriniz" 
                                           value="<?php echo isset($_POST['kullaniciadi']) ? htmlspecialchars($_POST['kullaniciadi']) : ''; ?>" 
                                           required>
                                    <button type="submit" name="sorgu" class="btn btn-primary">
                                        <i class="bx bx-search-alt"></i> Hesap Sorgula
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            if (isset($_POST['sorgu'])) {
                $kullaniciadi = trim($_POST['kullaniciadi']);
                
                if (!empty($kullaniciadi)) {
            ?>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <?php
                            // Facebook sorgulama API'sine istek
                            $url = "https://dosya.alwaysdata.net/api/facebook_sorgu.php?kullaniciadi=" . urlencode($kullaniciadi);
                            $istek = @file_get_contents($url);
                            
                            if ($istek !== false) {
                                $data = json_decode($istek, true);
                                
                                if ($data && isset($data['data'])) {
                                    $sonuc = $data['data'];
                            ?>
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Hesap Bilgileri</h5>
                                            <div class="table-responsive">
                                                <table class="table table-bordered mb-0">
                                                    <thead class="table-light">
                                                        <tr>
                                                            <th>Bilgi</th>
                                                            <th>Değer</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>Kullanıcı Adı</td>
                                                            <td><strong><?php echo htmlspecialchars($sonuc['kullaniciadi'] ?? $kullaniciadi); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Tam Ad</td>
                                                            <td><?php echo isset($sonuc['tam_ad']) ? htmlspecialchars($sonuc['tam_ad']) : '-'; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Hesap Durumu</td>
                                                            <td>
                                                                <?php if (isset($sonuc['hesap_durumu'])): ?>
                                                                    <span class="badge bg-<?php echo $sonuc['hesap_durumu'] == 'aktif' ? 'success' : 'danger'; ?>">
                                                                        <?php echo htmlspecialchars($sonuc['hesap_durumu']); ?>
                                                                    </span>
                                                                <?php else: ?>
                                                                    -
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Hesap Türü</td>
                                                            <td><?php echo isset($sonuc['hesap_turu']) ? htmlspecialchars($sonuc['hesap_turu']) : '-'; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Oluşturulma Tarihi</td>
                                                            <td><?php echo isset($sonuc['olusturma_tarihi']) ? htmlspecialchars($sonuc['olusturma_tarihi']) : '-'; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Son Aktivite</td>
                                                            <td><?php echo isset($sonuc['son_aktivite']) ? htmlspecialchars($sonuc['son_aktivite']) : '-'; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-lg-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Ek Bilgiler</h5>
                                            <table class="table table-sm mb-0">
                                                <?php if (isset($sonuc['arkadas_sayisi'])): ?>
                                                <tr>
                                                    <td>Arkadaş Sayısı</td>
                                                    <td><?php echo htmlspecialchars($sonuc['arkadas_sayisi']); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                
                                                <?php if (isset($sonuc['katilim_tarihi'])): ?>
                                                <tr>
                                                    <td>Platforma Katılım</td>
                                                    <td><?php echo htmlspecialchars($sonuc['katilim_tarihi']); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                
                                                <?php if (isset($sonuc['email'])): ?>
                                                <tr>
                                                    <td>E-posta Adresi</td>
                                                    <td><?php echo htmlspecialchars($sonuc['email']); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                
                                                <?php if (isset($sonuc['telefon'])): ?>
                                                <tr>
                                                    <td>Telefon</td>
                                                    <td><?php echo htmlspecialchars($sonuc['telefon']); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php if (isset($sonuc['ilgili_hesaplar']) && !empty($sonuc['ilgili_hesaplar'])): ?>
                            <div class="row mt-4">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">İlgili Hesaplar</h5>
                                            <div class="row">
                                                <?php foreach ($sonuc['ilgili_hesaplar'] as $ilgili_hesap): ?>
                                                <div class="col-md-4 mb-3">
                                                    <div class="card">
                                                        <div class="card-body p-3">
                                                            <strong><?php echo htmlspecialchars($ilgili_hesap['kullaniciadi']); ?></strong><br>
                                                            <small class="text-muted"><?php echo htmlspecialchars($ilgili_hesap['ad'] ?? ''); ?></small>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php
                                } else {
                                    echo '<div class="alert alert-warning">Bu kullanıcı adına ait bilgi bulunamadı.</div>';
                                }
                            } else {
                                echo '<div class="alert alert-danger">Sorgu sırasında bir hata oluştu. Lütfen tekrar deneyin.</div>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                } else {
                    echo '<div class="row">';
                    echo '<div class="col-12">';
                    echo '<div class="alert alert-danger">Lütfen bir kullanıcı adı giriniz.</div>';
                    echo '</div></div>';
                }
            }
            ?>
        </div>
    </div>
</div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->

        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>


<script>
    var $table = $('#table');
    $(function () {
        buildTable($table, 8, 1);
    });
    function expandTable($detail, cells) {
        buildTable($detail.html('<table></table>').find('table'), cells, 1);
    }
    function buildTable($el, cells, rows) {
        var i, j, row,
                columns = [],
                data = [];
        for (i = 0; i < cells; i++) {
            columns.push({
                field: 'field' + i,
                title: 'Cell' + i,
                sortable: true
            });
        }
        for (i = 0; i < rows; i++) {
            row = {};
            for (j = 0; j < cells; j++) {
                row['field' + j] = 'Row-' + i + '-' + j;
            }
            data.push(row);
        }
        $el.bootstrapTable({
            columns: columns,
            data: data,
            detailView: cells > 1,
            onExpandRow: function (index, row, $detail) {
                expandTable($detail, cells - 1);
            }
        });
    }
</script>

   <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>

        <!-- Responsive Table js -->
        <script src="assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

        
        <script src="assets/js/app.js"></script>


    </body>

</html>
