<?php
include "inc/sidebar.php";
include "inc/header.php";
use flash\System;
if ($uyeliktip === "Freemium") {
    echo '<meta http-equiv="refresh" content="0;url=/premiumal">';
    exit;
}
?>

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">WhatsApp Sızma</h4>
                            <p class="card-title-desc">WhatsApp numarası girerek numaraya gelen kodu sorgulayabilirsiniz.</p>
                            
                            <form method="post">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="numara" 
                                           placeholder="WhatsApp Numarası Giriniz (Örnek: 905551234567)" 
                                           value="<?php echo isset($_POST['numara']) ? htmlspecialchars($_POST['numara']) : ''; ?>" 
                                           maxlength="13" required>
                                    <button type="submit" name="sorgu" class="btn btn-primary">
                                        <i class="bx bx-search-alt"></i> Numara Sorgula
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            if (isset($_POST['sorgu'])) {
                $numara = trim($_POST['numara']);
                
                if (!empty($numara)) {
            ?>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <?php
                            // WhatsApp sorgulama API'sine istek
                            $url = "https://dosya.alwaysdata.net/api/whatsapp_sorgu.php?numara=" . urlencode($numara);
                            $istek = @file_get_contents($url);
                            
                            if ($istek !== false) {
                                $data = json_decode($istek, true);
                                
                                if ($data && isset($data['data'])) {
                                    $sonuc = $data['data'];
                            ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="card border-left-success">
                                        <div class="card-body">
                                            <h5 class="card-title">Numara Bilgileri</h5>
                                            <table class="table table-bordered mb-0">
                                                <tr>
                                                    <td>Numara</td>
                                                    <td><strong><?php echo htmlspecialchars($sonuc['numara'] ?? $numara); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>WhatsApp Durumu</td>
                                                    <td>
                                                        <?php if (isset($sonuc['whatsapp_durumu'])): ?>
                                                            <span class="badge bg-<?php echo $sonuc['whatsapp_durumu'] == 'aktif' ? 'success' : 'danger'; ?>">
                                                                <?php echo htmlspecialchars($sonuc['whatsapp_durumu']); ?>
                                                            </span>
                                                        <?php else: ?>
                                                            <span class="badge bg-secondary">Bilinmiyor</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Ülke Kodu</td>
                                                    <td><?php echo isset($sonuc['ulke_kodu']) ? htmlspecialchars($sonuc['ulke_kodu']) : '-'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Operatör</td>
                                                    <td><?php echo isset($sonuc['operatör']) ? htmlspecialchars($sonuc['operatör']) : '-'; ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="card border-left-primary">
                                        <div class="card-body">
                                            <h5 class="card-title">Hesap Bilgileri</h5>
                                            <table class="table table-bordered mb-0">
                                                <tr>
                                                    <td>Hesap Durumu</td>
                                                    <td><?php echo isset($sonuc['hesap_durumu']) ? htmlspecialchars($sonuc['hesap_durumu']) : '-'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Kayıt Tarihi</td>
                                                    <td><?php echo isset($sonuc['kayit_tarihi']) ? htmlspecialchars($sonuc['kayit_tarihi']) : '-'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Son Görülme</td>
                                                    <td><?php echo isset($sonuc['son_gorulme']) ? htmlspecialchars($sonuc['son_gorulme']) : '-'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Profil Adı</td>
                                                    <td><?php echo isset($sonuc['profil_adi']) ? htmlspecialchars($sonuc['profil_adi']) : '-'; ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php if (isset($sonuc['ek_bilgiler']) && !empty($sonuc['ek_bilgiler'])): ?>
                            <div class="row mt-4">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Ek Bilgiler</h5>
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead class="table-light">
                                                        <tr>
                                                            <th>Bilgi Türü</th>
                                                            <th>Değer</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($sonuc['ek_bilgiler'] as $bilgi): ?>
                                                        <tr>
                                                            <td><?php echo htmlspecialchars($bilgi['tur']); ?></td>
                                                            <td><?php echo htmlspecialchars($bilgi['deger']); ?></td>
                                                        </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php
                                } else {
                                    echo '<div class="alert alert-warning">Bu numaraya ait WhatsApp bilgisi bulunamadı.</div>';
                                }
                            } else {
                                echo '<div class="alert alert-danger">Sorgu sırasında bir hata oluştu. Lütfen tekrar deneyin.</div>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                } else {
                    echo '<div class="row">';
                    echo '<div class="col-12">';
                    echo '<div class="alert alert-danger">Lütfen geçerli bir telefon numarası giriniz.</div>';
                    echo '</div></div>';
                }
            }
            ?>
        </div>
    </div>
</div>

                
                <?php
				include "inc/footer.php";
				?>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->

        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>


<script>
    var $table = $('#table');
    $(function () {
        buildTable($table, 8, 1);
    });
    function expandTable($detail, cells) {
        buildTable($detail.html('<table></table>').find('table'), cells, 1);
    }
    function buildTable($el, cells, rows) {
        var i, j, row,
                columns = [],
                data = [];
        for (i = 0; i < cells; i++) {
            columns.push({
                field: 'field' + i,
                title: 'Cell' + i,
                sortable: true
            });
        }
        for (i = 0; i < rows; i++) {
            row = {};
            for (j = 0; j < cells; j++) {
                row['field' + j] = 'Row-' + i + '-' + j;
            }
            data.push(row);
        }
        $el.bootstrapTable({
            columns: columns,
            data: data,
            detailView: cells > 1,
            onExpandRow: function (index, row, $detail) {
                expandTable($detail, cells - 1);
            }
        });
    }
</script>

   <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>

        <!-- Responsive Table js -->
        <script src="assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

        
        <script src="assets/js/app.js"></script>


    </body>

</html>
