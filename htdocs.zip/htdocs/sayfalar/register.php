<?php
include "server/database.php";

$hata = false;
$hataMesaji = "";
$basari = false;
$basariMesaji = "";

if (isset($_POST['kayit'])) {
    $kullaniciAdi = trim($_POST['kullanici_adi']);
    $sifre = $_POST['sifre'];
    $sifreTekrar = $_POST['sifre_tekrar'];
    
    if (empty($kullaniciAdi) || empty($sifre) || empty($sifreTekrar)) {
        $hata = true;
        $hataMesaji = "Tüm alanlar doldurulmalıdır.";
    } elseif (strlen($kullaniciAdi) < 3 || strlen($kullaniciAdi) > 20) {
        $hata = true;
        $hataMesaji = "Kullanıcı adı 3 ile 20 karakter arasında olmalıdır.";
    } elseif ($sifre !== $sifreTekrar) {
        $hata = true;
        $hataMesaji = "Girdiğiniz şifreler eşleşmiyor.";
    } elseif (strlen($sifre) < 6) {
        $hata = true;
        $hataMesaji = "Şifre en az 6 karakter olmalıdır.";
    } else {
        $stmt = $db->prepare("SELECT COUNT(*) FROM 31cekusers WHERE username = ?");
        $stmt->execute([$kullaniciAdi]);
        $kullaniciSayisi = $stmt->fetchColumn();
        
        if ($kullaniciSayisi > 0) {
            $hata = true;
            $hataMesaji = "Bu kullanıcı adı zaten kullanılmaktadır.";
        } else {
            $anahtar = base64_encode(random_bytes(16));
            $ekleStmt = $db->prepare("INSERT INTO 31cekusers (username, kkey, bitistarih, banned, durum) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY), 0, 1)");
            $sonuc = $ekleStmt->execute([$kullaniciAdi, $anahtar]);
            
            if ($sonuc) {
                $basari = true;
                $basariMesaji = "Kayıt işleminiz başarıyla tamamlanmıştır. Aşağıdaki anahtarı kullanarak giriş yapabilirsiniz:<br><br><strong>" . $anahtar . "</strong>";
            } else {
                $hata = true;
                $hataMesaji = "Kayıt sırasında bir hata oluştu. Lütfen tekrar deneyin.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kayıt Ol</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #0c0c1e 0%, #1a1a2e 50%, #16213e 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .kayit-container {
            width: 100%;
            max-width: 420px;
        }

        .kayit-card {
            background: rgba(20, 20, 35, 0.95);
            backdrop-filter: blur(25px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 35px 70px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.06);
            overflow: hidden;
        }

        .kayit-baslik {
            text-align: center;
            margin-bottom: 35px;
        }

        .kayit-baslik h2 {
            color: #ffffff;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .kayit-baslik p {
            color: rgba(255, 255, 255, 0.7);
            font-size: 15px;
        }

        .form-group {
            margin-bottom: 24px;
        }

        .form-label {
            display: block;
            color: rgba(255, 255, 255, 0.85);
            margin-bottom: 10px;
            font-weight: 500;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            height: 56px;
            padding: 16px;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 14px;
            color: #ffffff;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(59, 130, 246, 0.4);
            box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.12);
            outline: none;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.4);
        }

        .btn-kayit {
            width: 100%;
            height: 56px;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border: none;
            border-radius: 14px;
            color: #ffffff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-kayit:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 35px rgba(16, 185, 129, 0.4);
        }

        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            border: none;
            margin-bottom: 24px;
            font-size: 14px;
            text-align: center;
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.15);
            color: #fca5a5;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.15);
            color: #86efac;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .anahtar-kutusu {
            background: rgba(16, 185, 129, 0.2);
            border: 1px solid rgba(16, 185, 129, 0.3);
            border-radius: 12px;
            padding: 24px;
            text-align: center;
            margin-bottom: 24px;
            font-size: 16px;
        }

        .giris-link {
            text-align: center;
            margin-top: 24px;
            padding-top: 24px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
        }

        .giris-link a {
            color: #3b82f6;
            text-decoration: none;
            font-weight: 600;
        }

        .giris-link a:hover {
            color: #8b5cf6;
        }
    </style>
</head>
<body>
    <div class="kayit-container">
        <div class="kayit-card">
            <div class="kayit-baslik">
                <h2>Hesap Oluştur</h2>
                <p>Yeni bir hesap oluşturmak için gerekli bilgileri girin</p>
            </div>

            <?php if ($hata && !empty($hataMesaji)): ?>
                <div class="alert alert-danger"><?php echo $hataMesaji; ?></div>
            <?php endif; ?>

            <?php if ($basari && !empty($basariMesaji)): ?>
                <div class="anahtar-kutusu">
                    <strong>Kayıt Başarılı!</strong><br><br>
                    <?php echo $basariMesaji; ?>
                </div>
                <div class="giris-link">
                    <a href="index.php">Giriş Sayfasına Git</a>
                </div>
            <?php else: ?>
                <form method="post">
                    <div class="form-group">
                        <label class="form-label">Kullanıcı Adı</label>
                        <input type="text" class="form-control" name="kullanici_adi" 
                               placeholder="Kullanıcı adınızı girin" 
                               value="<?php echo isset($_POST['kullanici_adi']) ? htmlspecialchars($_POST['kullanici_adi']) : ''; ?>" 
                               required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Şifre</label>
                        <input type="password" class="form-control" name="sifre" placeholder="Şifrenizi girin" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Şifre Tekrar</label>
                        <input type="password" class="form-control" name="sifre_tekrar" placeholder="Şifrenizi tekrar girin" required>
                    </div>

                    <button type="submit" name="kayit" class="btn-kayit">Hesap Oluştur</button>
                </form>

                <div class="giris-link">
                    Zaten hesabınız var mı? <a href="index.php">Giriş Yap</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>