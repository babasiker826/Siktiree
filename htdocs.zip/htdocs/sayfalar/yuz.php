<?php
include "inc/sidebar.php";
include "inc/header.php";
use flash\System;
if ($uyeliktip === "Freemium") {
    echo '<meta http-equiv="refresh" content="0;url=/premiumal">';
    exit;
}
?>

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Yüz Sorgulama</h4>
                            <p class="card-title-desc">Yüz fotoğrafı ile <code>kişi bilgileri</code> bulabilirsiniz.</p>
                            
                            <form method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label class="form-label">Fotoğraf Yükle</label>
                                        <input type="file" class="form-control" name="yuz_resmi" accept="image/*">
                                    </div>
                                    <div class="col-lg-6">
                                        <label class="form-label">Ya da Fotoğraf Linki</label>
                                        <input type="text" class="form-control" name="yuz_url" placeholder="https://ornek.com/resim.jpg">
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <button type="submit" name="sorgu" class="btn btn-primary">
                                        <i class="bx bx-search-alt"></i>Sorgula
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            if (isset($_POST['sorgu'])) {
                $hata = "";
                if (empty($_FILES['yuz_resmi']['name']) && empty($_POST['yuz_url'])) {
                    $hata = "Lütfen fotoğraf yükle veya link gir.";
                }

                if ($hata) {
                    echo '<div class="alert alert-danger">'.$hata.'</div>';
                } else {
                    $api_url = "https://dosya.alwaysdata.net/api/fake_yuz_sorgu.php";
                    if (!empty($_FILES['yuz_resmi']['name'])) {
                        $api_url .= "?tip=dosya";
                    } else {
                        $api_url .= "?tip=url&veri=".urlencode(trim($_POST['yuz_url']));
                    }

                    $sonuc = @file_get_contents($api_url);
                    if ($sonuc === false) {
                        echo '<div class="alert alert-danger">Bağlantı hatası, tekrar dene.</div>';
                    } else {
                        $data = json_decode($sonuc, true);
                        if ($data && isset($data['sonuc'])) {
                            $s = $data['sonuc'];
            ?>
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body text-center">
                            <h2>
                                <span class="badge <?php echo $s['fake_mi'] ? 'bg-danger' : 'bg-success'; ?> fs-1 px-5 py-3">
                                    <?php echo $s['fake_mi'] ? 'FAKE YÜZ' : 'GERÇEK YÜZ'; ?>
                                </span>
                            </h2>
                            <p class="lead mt-3">
                                Yapay zeka tespit oranı: <strong><?php echo $s['yapay_zeka_orani']; ?>%</strong>
                            </p>
                            <p class="text-muted">
                                <?php echo $s['fake_mi'] ? 'Bu fotoğraf deepfake teknolojisiyle üretilmiş.' : 'Bu fotoğraf gerçek bir insana ait.'; ?>
                            </p>
                            <?php
                        } else {
                            echo '<div class="alert alert-warning">Sonuç alınamadı, tekrar dene.</div>';
                        }
                    }
                }
            }
            ?>
        </div>
    </div>
</div>
                        
                    </div>
                </div>
            </div>

                
                <?php
				include "inc/footer.php";
				?>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->

        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>


<script>
    var $table = $('#table');
    $(function () {
        buildTable($table, 8, 1);
    });
    function expandTable($detail, cells) {
        buildTable($detail.html('<table></table>').find('table'), cells, 1);
    }
    function buildTable($el, cells, rows) {
        var i, j, row,
                columns = [],
                data = [];
        for (i = 0; i < cells; i++) {
            columns.push({
                field: 'field' + i,
                title: 'Cell' + i,
                sortable: true
            });
        }
        for (i = 0; i < rows; i++) {
            row = {};
            for (j = 0; j < cells; j++) {
                row['field' + j] = 'Row-' + i + '-' + j;
            }
            data.push(row);
        }
        $el.bootstrapTable({
            columns: columns,
            data: data,
            detailView: cells > 1,
            onExpandRow: function (index, row, $detail) {
                expandTable($detail, cells - 1);
            }
        });
    }
</script>

   <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>

        <!-- Responsive Table js -->
        <script src="assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

        
        <script src="assets/js/app.js"></script>


    </body>

</html>
