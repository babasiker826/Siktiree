<?php
error_reporting(0);

include 'server/database.php';
require_once 'functions.php';

$username = $_SESSION['username'];

$title = ".";

if(!isset($username)){
	header("Location: /login");
	exit();
}

$baglan = $db->prepare("SELECT * FROM `31cekusers` WHERE username = :username");
$baglan->bindParam(':username', $username);
$baglan->execute();

while ($veri = $baglan->fetch()) {
    $uyeliktip = $veri['rol'];
	$profil = $veri['profil'];
	$süres = $veri['bitistarih'];
	$sorgusayisi = $veri['toplamsorgu'];
}

$tarih1 = new DateTime($süres);
$tarih2 = new DateTime();

$süre = $tarih1->diff($tarih2)->days;

$kullanicisayi = $db->query("SELECT
        (SELECT COUNT(*) FROM 31cekusers) AS toplam,
		(SELECT COUNT(*) FROM 31cekusers where banned = 1) AS banlisayisi,
        (SELECT COUNT(*) FROM 31cekusers WHERE rol = 1) AS premiumsayisi"
)->fetch(PDO::FETCH_ASSOC);

$uyeliktipsayi = $uyeliktip;
if($uyeliktip === 0){
	$uyeliktip = "Freemium";
}elseif($uyeliktip === 1){
	$uyeliktip = "Premium";
}elseif($uyeliktip === 2){
	$uyeliktip = "Admin";
}elseif($uyeliktip === 3){
	$uyeliktip = "Kurucu";
}
function getnamecolor($rol) {
    switch ($rol) {
        case 1:
            $color = "#66FF66";
            break;
        case 2:
            $color = "#FF8000";
            break;
        case 3:
            $color = "#00FFFF";
            break;
        default:
            $color = "white";
            break;
    }
    return $color;
}

function getarkaplan($rol) {
    switch ($rol) {
        case 1:
            $background = "https://xenforo.gen.tr/attachments/fire_green-gif.11061/";
            break;
        case 2:
            $background = "https://xenforo.gen.tr/attachments/fire_orange-gif.11057/";
            break;
        case 3:
            $background = "https://xenforo.gen.tr/attachments/fire_blue-gif.11059/";
            break;
        default:
            $background = "";
            break;
    }
    return $background;
}

$isimcolor = getnamecolor($uyeliktipsayi);
$backgroundpic = getarkaplan($uyeliktipsayi);

?>

<!doctype html>
<html lang="en">


<head>
        
        <meta charset="utf-8" />
        <title>Wakanda Sorgu Paneli</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/eze.png">
		
		<!-- DataTables -->
        <link href="assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />

        <!-- Responsive datatable examples -->
        <link href="assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />  


        <!-- Bootstrap Css -->
        <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
        <!-- App js -->
        <script src="assets/js/plugin.js"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

	<script>
		toastr.options = {
		  "closebutton": false,
		  "debug": false,
		  "newestontop": false,
		  "progressbar": false,
		  "positionclass": "toast-top-right",
		  "preventduplicates": false,
		  "onclick": null,
		  "showduration": "300",
		  "hideduration": "1000",
		  "timeout": "5000",
		  "extendedtimeout": "1000",
		  "showeasing": "swing",
		  "hideeasing": "linear",
		  "showmethod": "fadein",
		  "hidemethod": "fadeout"
		};
	
		
    </script>
	
	

    <body data-sidebar="dark" data-bs-theme="dark">



        <!-- Begin page -->
        <div id="layout-wrapper">

            
           
            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title" key="t-menu">Menu</li>

                            <li>
                                <a href="/anasayfa" class="waves-effect">
                                    <i class="bx bx-home"></i>
                                    <span key="t-home">Ana sayfa</span>
                                </a>
                            </li>
                            <li>
                            <li>
<a href="https://t.me/WakandaDeTanirlar" class="adminol-link">
    <i class='bx bx-dollar-circle'></i>
    <span>Admin Ol</span>
  </a>
</li>

<style>
  .adminol-link{
    display:flex;align-items:center;gap:6px;
    padding:8px 12px;
    border-radius:10px;
    font-weight:600;font-size:13px;
    color:#e5e7eb;
    background:rgba(45,20,60,.7); /* morumsu saydam */
    border:1px solid rgba(148,163,184,.18);
    position:relative;overflow:hidden;
    transition:transform .25s ease, box-shadow .25s ease, background .25s ease;
    will-change:transform;
  }

  /* Gradient çerçeve – mor/mavi tonları */
  .adminol-link::before{
    content:"";position:absolute;inset:0;padding:1px;border-radius:10px;
    background:linear-gradient(120deg,#8b5cf6,#a855f7,#ec4899);
    -webkit-mask:
      linear-gradient(#000 0 0) content-box,
      linear-gradient(#000 0 0);
    -webkit-mask-composite:xor;mask-composite:exclude;
    opacity:.45;
    pointer-events:none;
  }

  /* İç parıltı */
  .adminol-link::after{
    content:"";position:absolute;inset:0;border-radius:inherit;
    background:radial-gradient(60% 60% at 50% 50%, rgba(168,85,247,.25) 0%, transparent 70%);
    transform:scale(.9);
    opacity:0;transition:opacity .35s ease;
    pointer-events:none;
  }

  .adminol-link i{
    font-size:16px;
    color:#c084fc; /* açık mor ikon */
    transition:color .25s ease, transform .25s ease;
  }

  .adminol-link span{
    background:linear-gradient(90deg,#a855f7,#ec4899,#8b5cf6);
    background-size:160% 160%;
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    animation:txtShift 8s ease infinite;
  }

  .adminol-link:hover{
    background:rgba(60,20,80,.85);
    transform:scale(1.01);
    box-shadow:0 0 12px rgba(168,85,247,.35);
  }
  .adminol-link:hover::after{ opacity:1; }
  .adminol-link:hover i{ color:#ec4899; transform:scale(1.08); }

  @keyframes txtShift{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
  }

  .adminol-link.active{
    background:rgba(75,20,90,.95);
    box-shadow:0 0 10px rgba(168,85,247,.25);
  }
</style>

<li>
  <a href="https://t.me/WakandaDeTanirlar"
     class="telegram-link" target="_blank" rel="noopener noreferrer">
    <i class='bx bxl-telegram'></i>
    <span>Telegram Satış Hattı</span>
  </a>
</li>

<style>
  .telegram-link{
    display:flex;align-items:center;gap:6px;
    padding:8px 12px;
    border-radius:10px;
    font-weight:600;font-size:13px;
    color:#e5e7eb;
    background:rgba(10,30,50,.7); /* koyu mavi saydam */
    border:1px solid rgba(148,163,184,.18);
    position:relative;overflow:hidden;
    transition:transform .25s ease, box-shadow .25s ease, background .25s ease;
    will-change:transform;
  }

  /* Gradient çerçeve – Telegram renkleri */
  .telegram-link::before{
    content:"";position:absolute;inset:0;padding:1px;border-radius:10px;
    background:linear-gradient(120deg,#0088cc,#2ca5e0,#ffffff);
    -webkit-mask:
      linear-gradient(#000 0 0) content-box,
      linear-gradient(#000 0 0);
    -webkit-mask-composite:xor;mask-composite:exclude;
    opacity:.45;
    pointer-events:none;
  }

  /* İç parıltı */
  .telegram-link::after{
    content:"";position:absolute;inset:0;border-radius:inherit;
    background:radial-gradient(60% 60% at 50% 50%, rgba(0,136,204,.25) 0%, transparent 70%);
    transform:scale(.9);
    opacity:0;transition:opacity .35s ease;
    pointer-events:none;
  }

  .telegram-link i{
    font-size:16px;
    color:#2ca5e0;
    transition:color .25s ease, transform .25s ease;
  }

  .telegram-link span{
    background:linear-gradient(90deg,#2ca5e0,#ffffff);
    background-size:160% 160%;
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    animation:txtShift 8s ease infinite;
  }

  .telegram-link:hover{
    background:rgba(20,40,60,.85);
    transform:scale(1.01);
    box-shadow:0 0 12px rgba(0,136,204,.35);
  }
  .telegram-link:hover::after{ opacity:1; }
  .telegram-link:hover i{ color:#ffffff; transform:scale(1.08); }

  @keyframes txtShift{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
  }

  .telegram-link.active{
    background:rgba(15,35,55,.95);
    box-shadow:0 0 10px rgba(44,165,224,.25);
  }
</style>

							<li>
                                <a href="/premiumal" class="waves-effect">
                                    <i class="bx bx-store-alt"></i>
                                    <span key="t-premium">Premium satın al</span>
                                </a>
                            </li>
							<?php
							if($uyeliktip === "Kurucu"){
								$panelad = "Yönetici";
							}elseif($uyeliktip === "Admin"){
								$panelad = "Admin";
							}
							?>
							
							<?php
							if($uyeliktip === "Admin" || $uyeliktip === "Kurucu"){
							?>
							<li>
                                <a href="javascript: void(0);" class="has-arrow waves-effect">
								
                                    <i class="bx bxs-user-detail"></i>
                                    <span key="t-admin"><?= $panelad ?></span>
									
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    <li><a href="/kullanici" key="t-kullanıcı">Kullanıcılar</a></li>
									<li><a href="/rol" key="t-rol">Rol değiştir</a></li>
									<?php
									if($uyeliktip === "Kurucu"){
									?>
                                    <li><a href="/bildirim" key="t-bildirim">Bildirimler</a></li>
									<?php
									}
									?>
                                </ul>
                            </li>
							
                          <?php
							}
							?>
 <li class="menu-title" key="t-database">Hack İşlemleri</li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxl-instagram"></i>
                            <span key="t-kisi">Instagram Hack</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/insta" key="t-f">Instagram Sızma <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/insta" key="t-g">Instagram Çalma <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/insta" key="t-h">Instagram Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/insta" key="t-k">Instagram Kapatma <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxl-facebook"></i>
                            <span key="t-">Facebook Hack</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/face" key="t-f">Facebook Sızma <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/face" key="t-g">Facebook Çalma <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/face" key="t-h">Facebook Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/face" key="t-k">Facebook Kapatma <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-music"></i>
                            <span key="t-">Tiktok Hack</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/tt" key="t-f">Tiktok Sızma <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/tt" key="t-g">Tiktok Çalma <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/tt" key="t-h">Tiktok Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/tt" key="t-k">Tiktok Kapatma <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxl-whatsapp"></i>
                            <span key="t-">Whatsapp Hack</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/wphack" key="t-f">Whatsapp Sızma <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/wphack" key="t-g">Whatsapp Takip <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/wphack" key="t-h">Kapanan WP Açma <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/wphack" key="t-k">Kalıcı WP Kapatma <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-fingerprint"></i>
                            <span key="t-">Biyometrik</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/yuz" key="t-f">Yüz Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-cog"></i>
                            <span key="t-">Gelişmiş Çözümler</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/canlıknm" key="t-g">Anlık Canlı Konum Takip Sistemi <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/ibanv2" key="t-h">İban Sorgulama <span class="badge bg-success-subtle text-success">VİP</span></a></li>
                        </ul>
                    </li>

                    <li class="menu-title" key="t-database">Kişi</li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-id-card"></i>
                            <span key="t-kisi">Kişi</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/adsoyad" key="t-adsoyad">Ad Soyad <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/adv2" key="t-adsoyad">Ad Soyad V2 <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/tcsorgu" key="t-tcsorgu">Tc Sorgu <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/tcv2" key="t-tcsorgu">Tc Sorgu V2 <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/aile" key="t-aile">Aile Sorgu <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/sülale" key="t-sülale">Sülale Sorgu <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/soyagac" key="t-sülale">SoyAğaç Sorgu <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/kardes" key="t-sülale">Kardeş Sorgu <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/es" key="t-sülale">Eş Sorgu <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/aile" key="t-f">Aile GSM <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/adsgsm" key=" STE">Sulale GSM <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/sulale" key="t-f">Kuzen Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/aile" key="t-f">Aile Adres <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/aile" key="t-f">Güncel Aile <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/es" key="t-f">Eş - Çocuk Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-phone"></i>
                            <span key="t-gsmcozum">Gsm Çözümleri</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/adsgsm" key="t-tcgsm">Ad Soyad Gsm <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/tccgsm" key="t-tcgsm">Tc Gsm <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/gsmtc" key="t-gsmtc">Gsm Tc <span class="badge bg-success-subtle text-success">FREE</span></a></li>
                            <li><a href="/tccgsm" key="t-tcgsm">Güncel Tc Gsm <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/gsmtc" key="t-tcgsm">Güncel Gsm Tc <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li class="menu-title" key="t-egitim">Eğitim</li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxs-school"></i>
                            <span key="t-eokul">Eokul</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/eokulvesika" key="t-f">ÖSYM Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/sinavtarih" key="t-f">Öğretmen Sorgu<span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/devamsizlik" key="t-f">Sınıf Arkadaşı Sorgu<span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/eokulnumarası" key="t-f">Okul - Sınıf Sorgu<span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/belge" key="t-f">LGS Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/eokulvesika" key="t-eokulvesika">Vesika <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/eokulnumarası" key="t-eokulnumarası">Okul Numarası <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/belge" key="t-belge">Belge <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/devamsizlik" key="t-devamsizlik">Devamsızlık <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/yilsonu" key="t-yilsonu">Yılsonu Not <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/sinavtarih" key="t-sinavt">Sınav Tarihleri <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li class="menu-title" key="t-egitim">Gelişmiş çözümler</li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-car"></i>
                            <span key="t-arac">Araç Çözümleri</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/tcarac" key="t-tcarac">Araç Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/tcarac" key="t-tcarac">Plaka Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/tcarac" key="t-f">Araç Geçmişi <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-map-pin"></i>
                            <span key="t-ikametgah">Ikametgah</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/adres" key="t-adres">Güncel Adres Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/adres" key="t-adres">Vergi No Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxs-user-detail"></i>
                            <span key="t-detay">Detaylı Kişi İşlemleri</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/tcpro" key="t-tcpro">Tc Pro+ Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/tcpro" key="t-ailesrno">Aile Sıra No Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/tcpro" key="t-bireysrno">Birey Sıra No Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/tcpro" key="t-mdnihal">Medeni Hal Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxs-user-detail"></i>
                            <span key="t-detay">İşyeri</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/isyeri" key="t-isyeri">İşyeri Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/yisyeri" key="t-aisyeri">İşyeri Yetkili Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/aisyeri" key="t-aisyeri">İşyeri Arkadaşı Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>

                    <li class="menu-title" key="t-egitim">Sağlık</li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="fas fa-syringe"></i>
                            <span key="t-saglik">Sağlık</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="/ilac" key="t-f">Eczane Kayıt Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/muayene" key="t-f">Hastane Geçmiş Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/ilac" key="t-f">Gebelik Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/ilac" key="t-ilac">İlaç Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                            <li><a href="/muayene" key="t-muayene">Muayene Sorgu <span class="badge bg-success-subtle text-success"> </span></a></li>
                        </ul>
                    </li>
							
							
							
							
                           

                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->