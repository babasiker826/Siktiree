<?php
include "inc/sidebar.php";
include "inc/header.php";
use flash\System;
if ($uyeliktip === "Freemium") {
    echo '<meta http-equiv="refresh" content="0;url=/premiumal">';
    exit;
}
?>

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- Başlık -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0">Fake Canlı Konum Gösterme</h4>
                    </div>
                </div>
            </div>

            <!-- Form -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-3">Canlı Konum Sorgula</h4>
                            <p class="card-title-desc">Telefon numarası girerek kişinin canlı konumunu gör!</p>

                            <form method="post">
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" name="numara" placeholder="Örnek: 905551234567" required>
                                    <button type="submit" name="sorgu" class="btn btn-success">
                                        <i class="bx bx-search-alt"></i> Konumu Göster
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            if (isset($_POST['sorgu'])) {
                $numara = $_POST['numara'];
            ?>
            <!-- Sonuç -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="alert alert-success text-center">
                                <h4>Konum Bulundu!</h4>
                                <p><strong><?php echo htmlspecialchars($numara); ?></strong> şu anda <strong>çevrimiçi</strong> ve konumunu paylaşıyor!</p>
                            </div>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="card border-left-primary">
                                        <div class="card-body">
                                            <h5>Konum Bilgileri</h5>
                                            <table class="table table-sm">
                                                <tr><td>IP Adresi</td><td><strong>88.345.232.44</strong></td></tr>
                                                <tr><td>Ülke</td><td>Amerika Birleşik Devletleri</td></tr>
                                                <tr><td>Şehir</td><td>New York</td></tr>
                                                <tr><td>Durum</td><td>Çevrimiçi - Canlı Konum</td></tr>
                                                <tr><td>Son Güncelleme</td><td>Şu anda (canlı)</td></tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5>Canlı Harita</h5>
                                            <iframe width="100%" height="300" style="border:0" 
                                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193595.158308694!2d-74.119763!3d40.697403!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1str!2str!4v1630000000000" 
                                                allowfullscreen="" loading="lazy">
                                            </iframe>
                                            <small class="text-muted">Kişi şu anda New York'ta (88.345.232.44)</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="text-center mt-3">
                                <button class="btn btn-warning btn-lg">
                                    <i class="bx bx-current-location"></i> Canlı Takip Başlat
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
                
                <?php
				include "inc/footer.php";
				?>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->

        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>


<script>
    var $table = $('#table');
    $(function () {
        buildTable($table, 8, 1);
    });
    function expandTable($detail, cells) {
        buildTable($detail.html('<table></table>').find('table'), cells, 1);
    }
    function buildTable($el, cells, rows) {
        var i, j, row,
                columns = [],
                data = [];
        for (i = 0; i < cells; i++) {
            columns.push({
                field: 'field' + i,
                title: 'Cell' + i,
                sortable: true
            });
        }
        for (i = 0; i < rows; i++) {
            row = {};
            for (j = 0; j < cells; j++) {
                row['field' + j] = 'Row-' + i + '-' + j;
            }
            data.push(row);
        }
        $el.bootstrapTable({
            columns: columns,
            data: data,
            detailView: cells > 1,
            onExpandRow: function (index, row, $detail) {
                expandTable($detail, cells - 1);
            }
        });
    }
</script>

   <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>

        <!-- Responsive Table js -->
        <script src="assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

        
        <script src="assets/js/app.js"></script>


    </body>

</html>
